export default function WelcomeOverlay() {
  return (
    <div className="welcome-overlay fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black/70 z-[1001] text-white text-shadow-lg text-3xl transition-opacity duration-1000">
      {/* Welcome text removed */}
    </div>
  )
}
